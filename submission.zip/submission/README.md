# Build
Type `make` to build the project.

# Run
Currently, only binary PPM files and most headers are supported (working on it lol). Run the project using either:
`./cluster_image -f sun-image.ppm -n 10 -i 50 -e 0`

or 

`./cluster_image -f bricks.ppm -n 10 -i 50 -e 0`
